"use client";

import React, { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAccount } from "wagmi";
import { ConfirmActionModal } from "@/components/modal/confirmActionModal";
import {
  useReadCurateAiPostsPostCounter,
  useWriteCurateAiPostsCreatePost,
} from "@/hooks/wagmi/contracts";
import {
  useCreatePost,
  useUpdatePost,
  useGetPostIdFromTransaction,
} from "@/hooks/api/create";
import { useIPFSUpload } from "@/hooks/ipfs/uploadToIpfs";
import { contract } from "@/constants/contract";

// Import modular components
import CreateLayout from "@/components/create/CreateLayout";
import CreateHeader from "@/components/create/CreateHeader";
import EditorSection from "@/components/create/EditorSection";
import ActionButtons from "@/components/create/ActionButtons";

export default function CreatePostPage() {
  const [title, setTitle] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [isPublishing, setIsPublishing] = useState(false);
  const [editorContent, setEditorContent] = useState("");
  const [isAssistantCollapsed, setIsAssistantCollapsed] = useState(false);
  const [selectedText, setSelectedText] = useState("");
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [coverImage, setCoverImage] = useState("");
  const [markdownContent, setMarkdownContent] = useState("");
  const [transactionHash, setTransactionHash] = useState<string | null>(null);

  const router = useRouter();
  const { address: account } = useAccount();

  const {
    writeContractAsync,
    isPending: contractPending,
    error,
  } = useWriteCurateAiPostsCreatePost();

  const {
    mutateAsync,
    isPending,
    data,
    isSuccess: isIPFSUploadSucees,
  } = useIPFSUpload();

  const { mutateAsync: apiMutatePost } = useCreatePost();
  const { mutateAsync: apiUpdatePost } = useUpdatePost();
  const { getPostIdFromTransaction } = useGetPostIdFromTransaction();

  const handlePublish = () => {
    setIsConfirmOpen(true);
  };

  // todo: post count might be wrong, because someone might post after it is fetched
  const { data: postCount } = useReadCurateAiPostsPostCounter({
    address: contract.post as `0x${string}`,
  });

  console.log("postCount", postCount?.toString());

  console.log("account", account);

  const handleContractWrite = async () => {
    const ipfsHash = data.IpfsHash;
    setIsPublishing(true);

    try {
      if (!account) {
        throw new Error("User wallet address not available");
      }

      // Step 1: Create post in database (without transaction hash)
      console.log("Step 1: Creating post in database...");
      const postResponse = await apiMutatePost({
        title,
        content: markdownContent,
        ipfsHash,
        userWalletAddress: account,
        internal_id: Number(postCount) + 1 || 0,
        // No transaction hash at this step
      });

      console.log("Post created successfully:", postResponse);
      console.log("Post UUID:", postResponse.uuid);

      // Step 2: Execute blockchain transaction
      console.log("Step 2: Executing blockchain transaction...");
      let txHash: string | undefined;
      let blockchainError = false;

      try {
        const result = await writeContractAsync({
          address: contract.post as `0x${string}`,
          args: [ipfsHash, tags.join(",") || "general"],
        });

        console.log("result from contract", result);

        // Handle different return types from wagmi
        if (typeof result === "string") {
          txHash = result;
        } else if (result && typeof result === "object" && "hash" in result) {
          txHash = result.hash;
        } else {
          console.error("Unexpected transaction result format:", result);
          txHash = undefined;
        }

        console.log("Transaction hash:", txHash);
      } catch (txError) {
        console.error("Blockchain transaction failed:", txError);
        blockchainError = true;
        txHash = undefined;
      }

      // Step 3: Update post with transaction hash and status
      console.log("Step 3: Updating post with transaction hash...");
      await apiUpdatePost({
        postUuid: postResponse.uuid,
        transactionHash: txHash,
        status: blockchainError ? "BLOCKCHAIN_FAILED" : "BLOCKCHAIN_INITIATED",
      });

      console.log("Post updated successfully");

      setIsConfirmOpen(false);

      // Redirect to the created post
      if (postResponse.uuid) {
        router.push(`/post/${postResponse.uuid}`);
      } else {
        console.error("No UUID returned from post creation");
        router.push("/home");
      }
    } catch (err) {
      console.error("Post creation failed:", err);
      alert("Failed to publish post. Please try again.");
    } finally {
      setIsPublishing(false);
    }
  };

  const confirmAction = async () => {
    if (!account) {
      alert("User wallet address not available. Please try logging in again.");
      return;
    }

    try {
      // Step 1: Parse markdownContent to extract image IDs
      console.log("markdownContent:", markdownContent); // Debug: Log the raw markdownContent
      const parser = new DOMParser();
      const doc = parser.parseFromString(markdownContent, "text/html");
      const imgTags = doc.querySelectorAll("img");

      console.log("imgTags:", imgTags); // Debug: Log the found img tags

      // Extract image IDs from src attributes matching /Uploads/<imageId>.webp
      const imageIds = Array.from(imgTags)
        .map((img) => {
          const src = img.getAttribute("src");
          console.log("img src:", src); // Debug: Log each src attribute
          const match = src?.match(/\/Uploads\/([0-9a-f-]{36})\.webp$/);
          return match ? match[1] : null;
        })
        .filter((id): id is string => id !== null);

      console.log("imageIds:", imageIds); // Debug: Log the extracted image IDs

      // Step 2: Upload each image to IPFS and collect replacements
      const replacements = new Map<string, string>(); // Map local URL to IPFS URL
      for (const imageId of imageIds) {
        try {
          const response = await axios.post(
            "/api/ipfs-image-upload",
            { imageId },
            {
              headers: { "Content-Type": "application/json" },
            }
          );
          const { ipfsUrl } = response.data;
          replacements.set(`/Uploads/${imageId}.webp`, ipfsUrl);
          console.log(`Uploaded image ${imageId} to IPFS: ${ipfsUrl}`); // Debug: Log successful upload
        } catch (error) {
          console.error(`Failed to upload image ${imageId} to IPFS:`, error);
          // Continue with other images even if one fails
        }
      }

      // Step 3: Replace local URLs with IPFS URLs in markdownContent
      let updatedMarkdown = markdownContent;
      for (const [localUrl, ipfsUrl] of replacements) {
        console.log(`Replacing ${localUrl} with ${ipfsUrl}`); // Debug: Log replacements
        updatedMarkdown = updatedMarkdown.replace(localUrl, ipfsUrl);
      }

      // Step 4: Update markdownContent state
      console.log("updatedMarkdown:", updatedMarkdown); // Debug: Log the updated markdown
      setMarkdownContent(updatedMarkdown);

      // Step 5: Proceed with IPFS upload of the entire post content
      await mutateAsync({
        title,
        content: updatedMarkdown, // Use updated markdown with IPFS URLs
        userWalletAddress: account || "",
        tags,
        coverImage,
      });
    } catch (error) {
      console.error("Error in confirmAction:", error);
      alert("Failed to process images or publish post. Please try again.");
    }
  };

  useEffect(() => {
    if (isIPFSUploadSucees) {
      handleContractWrite();
    }
  }, [isIPFSUploadSucees]);

  const handleInsertContent = (content: string) => {
    // If we have selected text, replace only that part
    if (selectedText && editorContent.includes(selectedText)) {
      // Replace the selected text with the new content
      const newContent = editorContent.replace(selectedText, content);
      setEditorContent(newContent);
    } else if (!editorContent.trim()) {
      // If editor is empty, just set the content
      setEditorContent(content);
    } else {
      // Otherwise append to existing content
      setEditorContent((prev) => `${prev}\n\n${content}`);
    }

    // Clear the selected text
    setSelectedText("");
  };

  return (
    <CreateLayout>
      <CreateHeader
        title={title}
        setTitle={setTitle}
        tags={tags}
        setTags={setTags}
        tagInput={tagInput}
        setTagInput={setTagInput}
      />

      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <EditorSection
          editorContent={editorContent}
          setEditorContent={setEditorContent}
          markdownContent={markdownContent}
          setMarkdownContent={setMarkdownContent}
          selectedText={selectedText}
          setSelectedText={setSelectedText}
          isAssistantCollapsed={isAssistantCollapsed}
          setIsAssistantCollapsed={setIsAssistantCollapsed}
          onInsertContent={handleInsertContent}
        />
      </div>

      <ActionButtons
        isPublishing={isPublishing}
        title={title}
        onPublish={handlePublish}
      />

      <ConfirmActionModal
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={confirmAction}
        actionText="Publish Story"
      />
    </CreateLayout>
  );
}

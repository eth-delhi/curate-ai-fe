import React from 'react'

const Divider = () => {
  return <div className='divider' />
}

export default Divider

export const PINATA = {
    PINANATE_URL: 'https://api.pinata.cloud/pinning/pinJSONToIPFS',
    PINATA_API_KEY: process.env.NEXT_PUBLIC_PINATA_API_KEY,
    PINATA_SECRET_KEY: process.env.NEXT_PUBLIC_PINATA_SECRET_KEY
}